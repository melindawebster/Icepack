The latest information about CICE or Icepack forcing data and files can be found at the GitHub 
Resource Index: https://github.com/CICE-Consortium/About-Us/wiki/Resource-Index
under the "Input Data" link.


